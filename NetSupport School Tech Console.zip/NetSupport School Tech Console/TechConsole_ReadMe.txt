
In order to get the Tech Console working on another machine, copy the contents to the Portable Tech Console (including sub folders) to that machine (via eg a pen drive) and then register the COM object IcoViewer.dll on that machine.

Cmd prompt -> Regsvr32 <path>IcoViewer.dll